import cv2
import pygame #Descargar con (pip install pygame) :3
#Ruta de los archivos
video_path = "videoo.mp4"
audio_path = "audioo.mp3"
#Inicializar pygame para reproducir audio
pygame.mixer.init()
pygame.mixer.music.load(audio_path)
pygame.mixer.music.play()
#Abrir el video
cap = cv2.VideoCapture(video_path)
#Verificar si se pudo abrir
if not cap.isOpened():
    print("No se pudo abrir el video")
    exit()
#Reproducir el video
while True:
    ret, frame = cap.read()
    if not ret:
        break

    #Mostrar la imagen en una ventana
    cv2.imshow("Video con sonido", frame)
    #Salir si se presiona la tecla 'q'
    if cv2.waitKey(25) & 0xFF == ord('q'):
        break
#Liberar recursos
cap.release()
cv2.destroyAllWindows()
pygame.mixer.music.stop()
